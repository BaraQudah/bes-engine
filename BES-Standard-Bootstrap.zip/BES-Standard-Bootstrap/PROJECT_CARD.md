# Project Card Template

## Identity
## Vision
## Scope
## Architecture Snapshot
## Tech Stack
## Constraints
## Success Definition
