# Work Order Template

## Objective
## Scope
## Acceptance Criteria
## Constraints
## Inputs
## Outputs
## Definition of Done
