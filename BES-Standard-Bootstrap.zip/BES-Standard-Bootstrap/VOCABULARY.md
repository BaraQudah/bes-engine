# Vocabulary

- Project Card: Project identity and stable context.
- Work Order: A single executable task.
- Decision Record: Architecture/business decision.
- Evidence: Observation from execution.
- Lesson: Reusable learning.
