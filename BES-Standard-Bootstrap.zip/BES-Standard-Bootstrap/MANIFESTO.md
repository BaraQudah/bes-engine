# BES Manifesto

- Evidence Before Rules
- Simplicity First
- Think Before Coding
- Verifiable Goals
- No Feature Creep
- AI-Agnostic
- Living Standard
